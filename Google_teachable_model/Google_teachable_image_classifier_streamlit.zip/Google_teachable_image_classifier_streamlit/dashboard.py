import streamlit as st
from PIL import Image
# from img_classification import *
import keras
from PIL import Image, ImageOps
import numpy as np
 
def teachable_machine_classification(img, file):
    # Disable scientific notation for clarity
    np.set_printoptions(suppress=True)

    # Load the model
    model = keras.models.load_model(file)

    # Create the array of the right shape to feed into the keras model
    # The 'length' or number of images you can put into the array is
    # determined by the first position in the shape tuple, in this case 1.
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

    # Replace this with the path to your image
    image = img

    #resize the image to a 224x224 with the same strategy as in TM2:
    #resizing the image to be at least 224x224 and then cropping from the center
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.ANTIALIAS)

    #turn the image into a numpy array
    image_array = np.asarray(image)
    # Normalize the image
    normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1

    # Load the image into the array
    data[0] = normalized_image_array

    # run the inference
    prediction = model.predict(data)
    return np.argmax(prediction) # return position of the highest probability


st.sidebar.markdown("Welcome to Pataa Navigation Pvt Ltd.")
st.title("Image Classification with Google's Teachable Machine")
st.header("Property Image Classification Example")
st.write("Upload images for quick analysis")
    # file upload and handling logic
uploaded_file = st.file_uploader("Choose a image ...", type=["jpg","jpeg","png"])
if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded image.', use_column_width=True)
    st.write("")
    st.write("Classifying...")
    label = teachable_machine_classification(image, 'model/keras_model.h5')
    if label == 0:
        st.write("Yes! this is property")
    # elif label == 1:
    #     st.write("The image depicts Common_rust")
    # elif label == 2:
    #     st.write("The image depicts Cercospora_leaf_spot Gray_leaf_spot")
    elif label == 1:
        st.write("No! this is not a property")
    else:
        st.write("Error")

         

