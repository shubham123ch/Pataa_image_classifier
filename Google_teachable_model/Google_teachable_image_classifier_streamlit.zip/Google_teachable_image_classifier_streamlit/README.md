# Picture-lytics
Using Google's teachable machine to generate an image classification model and serving the model via streamlit.
# Teachable Machine.
An amazing online tool that allows one to train and download an image, sound or pose classifier. <br/>
Checkout the repo under the screenshots folder of the tool in action.<br/> Link: https://teachablemachine.withgoogle.com/

# to run the app use : 
streamlit run dashboard.py


